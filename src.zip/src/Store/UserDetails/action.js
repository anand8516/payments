export const updateUserDetails= (user)=>{
    return {
        type: "USER_DETAILS",
        data: user
    }
}